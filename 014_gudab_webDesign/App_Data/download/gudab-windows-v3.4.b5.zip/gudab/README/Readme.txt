Introduction
gudab is a software which offers enterprises�� MongoDB management in 6 main sectors of Monitor, Alert, Backup & Restore, Activity, Dashboard and User control. 
gudab automatically collects and organizes data within MongoDB, users can operate all gudab��s functions through web browser.

MongoDB requirement
(1) MongoDB version : V2.6~3.6
(2) OS version
    a.Rehat6�BRedhat7
    b.CentOS6�BCentOS7
    c.Ubuntu14�BUbuntu16
    d.Windows Server 2008 R2 64-bit and later
(3) For Linux OS, please register a Linux account e.g.account name: gudab) in order to obtain host status statistics (CPU/Memory/Storage/Swap). 
        For Windows OS, host status statistics are currently not supported.
(4) Establishing MongoDB service account, please refer to Gudab v3.4.b5 system integration document.  
(5) Edit Host file : please refer to Gudab v3.4.b5 system integration document.  

System Requirement
(1) Java 1.8
(2) OS version
    a.Redhat6�BRedhat7
    b.CentOS6�BCentOS7
    c.Ubuntu14�BUbuntu16
    d.Windows Server 2008 R2 64-bit and later
(3) Hardware requirements
    a.CPU�Gminimum: 4core, recommend: 8core and above.
    b.RAM�Gminimum: 16GB, recommend: 32GB and above.
    c.Storage�GInstallation, Performance metric, Backup.
       I.Installation: 300MB
       II.Performance metrics�Gminimum; 10GB, recommend: 20GB for 10 host/month.
       III.Backup�Gminimum: 150% of the data size, recommend: 250% of the data size
        Note: Set at least one consoleDB on MongoDB for monitoring only. (No backup).

Installation
(1) Download gudab express from offical website. http://www.gudab.com
(2) Unzip file to any directory but the path cannot contain symbols. e.g. []
(3) Edit Host file : please refer to Gudab v3.4.b5 system integration document. 
(4) SSH public key Authentication�Bedit SSH properties file please refer to Gudab v3.4.b5 system integration document.
(5) Edit gudab properties file : please refer to Gudab v3.4.b5 system integration document. 
(6) Firewall port setting : please refer to Gudab v3.4.b5 system integration document.
(7) Prepare file to designated path : please refer to Gudab v3.4.b5 system integration document.
(8) Change consoleDB password : execute changePwd.sh (linux) or changePwd.bat (windows)�C 
(9) Activate gudab�Gexecute start.sh (linux) or start.bat (windows)

Authentication & Change Passwords
(1) Gudab login : Default user/pwd is root/root. Please change your pwd on you first login
(2) connect consoleDB : user/pwd is root/gudab, you can chage pwd by changePWD.sh(.bat)
* consoleDB = It's MongoDB in Gudab, which store metadata, metrics, etc.

Note : consoleDB default localhost is 27027. To modify please refer to Q&A on the official website 

Terms of use 
Please refer to License.txt 
